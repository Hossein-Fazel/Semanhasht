#include "Semanhasht.hpp"
#include <iostream>
#include <map>

using namespace std;

int main()
{
    SMHT S1;
    
    S1.start();

    return 0;
}